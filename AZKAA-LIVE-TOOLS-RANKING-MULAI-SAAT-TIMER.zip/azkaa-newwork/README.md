# AZKAA LIVE TOOLS

## Fitur Auction terbaru
- Tabel ranking peserta lelang tampil tepat di bawah timer.
- Kolom ranking: Rank, Username TikTok, Total Coin.
- Ranking otomatis diurutkan dari total coin terbesar ke terkecil.
- Total coin setiap username diakumulasikan terpisah.
- Extra time otomatis bertambah ketika gift masuk saat sisa waktu berada dalam jendela extra time yang diatur.
- Jika Top 1 dan Top 2 memiliki total coin yang sama (dan lebih dari 0), sistem otomatis memulai hitung mundur DRAW selama 20 detik.
- Saat DRAW aktif, timer lelang otomatis diperpanjang minimal sampai akhir jendela 20 detik. Jika sampai hitung mundur selesai kedua posisi masih seri, status lelang menjadi DRAW. Jika seri terpecahkan, hitung mundur DRAW dibatalkan.

## Menjalankan di Windows
1. Install Node.js versi LTS.
2. Ekstrak ZIP ini.
3. Buka folder hasil ekstrak di Terminal / Command Prompt.
4. Jalankan `npm install`.
5. Jalankan `npm start`.
6. Buka `http://localhost:3000`.

Catatan: fitur ranking, countdown DRAW, dan logika timer dibuat di aplikasi. Koneksi TikTok LIVE memakai library pihak ketiga dan perlu diuji saat LIVE karena kompatibilitasnya dapat berubah mengikuti perubahan TikTok.
