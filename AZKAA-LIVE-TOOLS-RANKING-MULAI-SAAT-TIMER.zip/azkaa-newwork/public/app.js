const socket = io();
const $ = id => document.getElementById(id);
const fmt = n => Number(n || 0).toLocaleString('id-ID');
$('overlayUrl').textContent = `${location.origin}/overlay`;
$('auctionOverlayUrl').textContent = `${location.origin}/overlay?mode=auction`;
function renderDashboard(data) {
  $('viewers').textContent = fmt(data.stats.viewers); $('likes').textContent = fmt(data.stats.likes);
  $('diamonds').textContent = fmt(data.stats.diamonds); $('gifts').textContent = fmt(data.stats.gifts);
  const connected = data.status === 'connected';
  $('statusPill').classList.toggle('connected', connected);
  $('statusPill').innerHTML = `<i></i> ${String(data.status || 'disconnected').toUpperCase()}`;
  $('connectionMessage').textContent = data.status === 'connected' ? `Terhubung ke @${data.username}` : (data.status === 'connecting' ? `Sedang menghubungkan ke @${data.username}...` : (data.activity?.[0]?.message || 'Belum terhubung ke TikTok LIVE.'));
  $('leaderboardRows').innerHTML = data.leaderboard.length ? data.leaderboard.map((u,i)=>`<div class="leader-row"><span class="rank">#${i+1}</span><div class="user-info"><b>@${esc(u.username || 'username-tidak-tersedia')}</b></div><span class="num coin">${fmt(u.coins)} coin</span></div>`).join('') : '<div class="empty">Belum ada gift masuk.</div>';
  const auctionPeople = data.auctionLeaderboard || [];
  const auctionRows = data.auction?.status !== 'running'
    ? '<div class="empty">Peserta akan muncul setelah timer lelang dimulai.</div>'
    : (auctionPeople.length ? auctionPeople.map((u,i)=>{const medal=['🥇','🥈','🥉'][i]||`#${i+1}`;return `<div class="auction-rank-row" role="row"><span class="auction-rank-medal">${medal}</span><b class="auction-rank-user">@${esc(u.username || 'username-tidak-tersedia')}</b><strong class="auction-rank-coins">${fmt(u.coins)}</strong></div>`;}).join('') : '<div class="empty">Belum ada peserta. Gift yang masuk sekarang akan dihitung.</div>');
  $('auctionLeaderboardRows').innerHTML = auctionRows;
  $('activityRows').innerHTML = data.activity.length ? data.activity.map(a=>activityHTML(a)).join('') : '<div class="empty">Aktivitas LIVE akan muncul di sini.</div>';
}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function activityHTML(a){let icon={gift:'◇',comment:'☰',like:'♡',follow:'＋',status:'◉',error:'!' }[a.type]||'•';let title={gift:'Gift diterima',comment:'Komentar baru',like:'Like masuk',follow:'Follower baru',status:'Status koneksi',error:'Koneksi error'}[a.type]||a.type;let desc=a.type==='gift'?`${esc(a.nickname)} (@${esc(a.username||'-')}) mengirim ${esc(a.giftName)} ×${a.repeat} · ${fmt(a.coins)} coin`:a.type==='comment'?`${esc(a.nickname)}: ${esc(a.message)}`:a.type==='like'?`${esc(a.nickname)} memberi ${fmt(a.count)} like`:a.type==='follow'?`${esc(a.nickname)} mulai mengikuti`:esc(a.message||'');return `<div class="activity-row"><div class="activity-icon">${icon}</div><div class="activity-copy"><b>${title}${a.test?' · TEST':''}</b><p>${desc}</p><small>${esc(a.time||'')}</small></div></div>`;}
let latestDashboard = null;
function render(data) { latestDashboard = data; renderDashboard(data); }
socket.on('dashboard:update', render);
$('connectForm').addEventListener('submit', async e=>{e.preventDefault();const username=$('username').value.trim();$('connectionMessage').textContent='Menghubungkan...';$('connectBtn').disabled=true;try{const r=await fetch('/api/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username})});const d=await r.json();$('connectionMessage').textContent=d.message||d.error||'Selesai';}catch(err){$('connectionMessage').textContent='Tidak dapat menghubungi server.';}finally{$('connectBtn').disabled=false;}});
$('disconnectBtn').onclick=async()=>{await fetch('/api/disconnect',{method:'POST'});};
document.querySelectorAll('[data-test]').forEach(b=>b.onclick=async()=>{await fetch('/api/test-event',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:b.dataset.test})});});
$('resetBtn').onclick=async()=>{if(confirm('Reset semua statistik dan leaderboard?'))await fetch('/api/reset',{method:'POST'});};
fetch('/api/status').then(r=>r.json()).then(render).catch(()=>{});

const auctionFmt = ms => { const sec=Math.max(0,Math.ceil((Number(ms)||0)/1000)); return String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0'); };
function renderAuction(a, message='') {
 if (!a) return;
 window.currentAuctionStatus = a.status;
 $('auctionTitleView').textContent = a.title || 'Lelang Item';
 $('auctionClock').textContent = auctionFmt(a.remainingMs);
 $('auctionStatus').textContent = String(a.status || 'idle').toUpperCase();
 $('auctionStatus').className = 'tag '+(a.status==='running'?'auction-running':'');
 $('auctionBid').textContent = fmt(a.currentBid)+' coin';
 $('auctionWinner').textContent = a.highestNickname ? `${a.highestNickname} (@${a.highestUsername || a.highestBidder || '-'})` : 'Belum ada';
 $('auctionBidCount').textContent = fmt(a.bidCount);
 $('auctionDrawStatus').textContent = a.drawActive ? `⚖ TOP 1 & TOP 2 SERI — DRAW ${Math.ceil((a.drawRemainingMs||0)/1000)} DETIK · EXTRA TIME OTOMATIS AKTIF` : (a.status==='draw' ? '⚖ HASIL AKHIR: DRAW / SERI' : '');
 $('auctionMessage').textContent = message || (a.status==='running'?'Lelang sedang berlangsung. Gift akan menambah bid otomatis.':a.status==='paused'?'Lelang dijeda.':a.status==='ended'?'Lelang selesai.':'Atur lelang lalu tekan Mulai Lelang.');
}
socket.on('auction:update', d => { renderAuction(d.auction,d.message); if (latestDashboard) { latestDashboard.auction = d.auction; renderDashboard(latestDashboard); } });
const postAuction = async (path, body={}) => { const r=await fetch('/api/auction/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const d=await r.json(); if(d.auction){renderAuction(d.auction); if(latestDashboard){latestDashboard.auction=d.auction;renderDashboard(latestDashboard);}} return d; };
$('auctionStart').onclick=()=>postAuction('start',{title:$('auctionTitle').value,durationSeconds:$('auctionDuration').value,startingBid:$('auctionStartingBid').value,extraSeconds:$('auctionExtra').value,extensionWindowSeconds:$('auctionWindow').value});
$('auctionPause').onclick=()=>postAuction('pause');
$('auctionResume').onclick=()=>postAuction('resume');
$('auctionEnd').onclick=()=>postAuction('end');
$('auctionReset').onclick=()=>postAuction('reset');
$('auctionTestBid').onclick=()=>postAuction('test-bid',{nickname:'Test Viewer',coins:10});
fetch('/api/auction').then(r=>r.json()).then(a=>renderAuction(a)).catch(()=>{});
