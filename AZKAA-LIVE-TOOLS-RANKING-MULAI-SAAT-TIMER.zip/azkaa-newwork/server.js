import express from 'express';
import http from 'node:http';
import { Server } from 'socket.io';
import { TikTokLiveConnection, WebcastEvent } from 'tiktok-live-connector';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let liveConnection = null;
let connectedUsername = '';
let liveStatus = 'disconnected';
const stats = { viewers: 0, likes: 0, diamonds: 0, gifts: 0, comments: 0, follows: 0 };
const leaderboard = new Map();
// Peserta khusus sesi lelang: hanya gift saat timer lelang RUNNING yang dihitung.
const auctionParticipants = new Map();
const activity = [];
const auction = {
  title: 'Lelang Item', status: 'idle', durationSeconds: 60,
  extraSeconds: 10, extensionWindowSeconds: 10, remainingMs: 0,
  endsAt: null, currentBid: 0, highestBidder: '', highestUsername: '', highestNickname: '',
  bidCount: 0, startedAt: null, drawEndsAt: null, drawRemainingMs: 0, drawActive: false, drawPreviousEndsAt: null
};
let auctionTick = null;
function auctionSnapshot() {
  const remainingMs = auction.status === 'running' && auction.endsAt
    ? Math.max(0, auction.endsAt - Date.now()) : auction.remainingMs;
  const drawRemainingMs = auction.drawActive && auction.drawEndsAt ? Math.max(0, auction.drawEndsAt - Date.now()) : 0;
  return { ...auction, remainingMs, drawRemainingMs, endsAt: auction.endsAt };
}
function publishAuction(message = '') {
  io.emit('auction:update', { auction: auctionSnapshot(), message });
}
function stopAuctionTimer() { if (auctionTick) clearInterval(auctionTick); auctionTick = null; }
function finishAuction() {
  stopAuctionTimer(); auction.status = 'ended'; auction.remainingMs = 0; auction.endsAt = null; auction.drawActive = false; auction.drawEndsAt = null; auction.drawPreviousEndsAt = null;
  publishAuction('Waktu lelang habis.');
  publish('auction', { message: `Lelang selesai: ${auction.highestNickname || 'Belum ada pemenang'}` });
}
function topTwoAreTied() {
  const top = [...auctionParticipants.values()].sort((a,b) => b.coins-a.coins).slice(0,2);
  return top.length === 2 && top[0].coins > 0 && top[0].coins === top[1].coins;
}
function updateDrawCountdown() {
  if (auction.status !== 'running') return;
  const tied = topTwoAreTied();
  if (tied && !auction.drawActive) {
    auction.drawActive = true;
    auction.drawEndsAt = Date.now() + 20000;
    // Simpan batas waktu lelang asli. Selama DRAW, timer lelang dijaga tetap hidup
    // minimal sampai countdown DRAW selesai.
    auction.drawPreviousEndsAt = auction.endsAt;
    if (auction.endsAt < auction.drawEndsAt) auction.endsAt = auction.drawEndsAt;
    publishAuction('TOP 1 dan TOP 2 seri! DRAW otomatis dimulai 20 detik.');
  } else if (!tied && auction.drawActive) {
    auction.drawActive = false; auction.drawEndsAt = null;
    // Kembalikan timer ke batas semula (termasuk extra time yang mungkin masuk).
    auction.endsAt = auction.drawPreviousEndsAt ?? auction.endsAt;
    auction.drawPreviousEndsAt = null;
    publishAuction('DRAW dibatalkan karena peringkat sudah berubah. Lelang dilanjutkan.');
  }
  if (auction.drawActive && auction.drawEndsAt && Date.now() >= auction.drawEndsAt) {
    if (topTwoAreTied()) {
      stopAuctionTimer(); auction.status = 'draw'; auction.remainingMs = 0; auction.endsAt = null;
      auction.drawRemainingMs = 0; auction.drawActive = false; auction.drawEndsAt = null; auction.drawPreviousEndsAt = null;
      publishAuction('DRAW! TOP 1 dan TOP 2 tetap seri setelah 20 detik.');
      publish('auction', { message: 'Hasil lelang DRAW karena TOP 1 dan TOP 2 seri.' });
    } else { auction.drawActive = false; auction.drawEndsAt = null; }
  }
}
function startAuctionTimer() {
  stopAuctionTimer();
  auction.endsAt = Date.now() + Math.max(0, auction.remainingMs);
  auction.status = 'running';
  auctionTick = setInterval(() => {
    updateDrawCountdown();
    if (auction.status !== 'running') return;
    auction.remainingMs = Math.max(0, auction.endsAt - Date.now());
    if (auction.remainingMs <= 0) finishAuction(); else publishAuction();
  }, 250);
  publishAuction('Lelang dimulai.');
}
function applyAuctionBid(nickname, username, coins) {
  if (auction.status !== 'running' || coins <= 0) return;
  auction.currentBid += coins; auction.bidCount++;
  auction.highestBidder = username || nickname; auction.highestUsername = username || ''; auction.highestNickname = nickname;
  const now = Date.now();
  const remaining = auction.endsAt - now;
  if (remaining > 0 && remaining <= auction.extensionWindowSeconds * 1000 && auction.extraSeconds > 0) {
    // Saat DRAW aktif, tambahkan extra time ke deadline normal yang disimpan,
    // bukan menggeser countdown DRAW 20 detik.
    if (auction.drawActive && auction.drawPreviousEndsAt !== null) {
      auction.drawPreviousEndsAt += auction.extraSeconds * 1000;
    } else {
      auction.endsAt += auction.extraSeconds * 1000;
    }
    auction.remainingMs = Math.max(0, auction.endsAt - now);
    publishAuction(`EXTRA TIME +${auction.extraSeconds} detik!`);
    publish('auction-extra', { nickname, seconds: auction.extraSeconds });
  }
  publishAuction(`${nickname} menambah bid ${coins} coin.`);
}

function snapshot() {
  return {
    username: connectedUsername, status: liveStatus,
    stats: { ...stats },
    leaderboard: [...leaderboard.values()].sort((a,b) => (b.coins-a.coins) || (b.gifts-a.gifts) || String(a.username).localeCompare(String(b.username))).slice(0,50),
    auctionLeaderboard: [...auctionParticipants.values()].sort((a,b) => (b.coins-a.coins) || (b.gifts-a.gifts) || String(a.username).localeCompare(String(b.username))).slice(0,50),
    activity: activity.slice(0,30), auction: auctionSnapshot()
  };
}
function publish(type, detail = {}) {
  const item = { id: Date.now() + Math.random(), type, time: new Date().toLocaleTimeString('id-ID'), ...detail };
  activity.unshift(item); activity.splice(30);
  io.emit('dashboard:update', snapshot());
  io.emit('live:event', item);
}
function setStatus(status, message = '') {
  liveStatus = status;
  publish('status', { message: message || status });
}
function markConnectedFromEvent() {
  // Some connector versions deliver LIVE events without the CONNECTED callback.
  // Receiving a real LIVE event proves the room stream is active.
  if (liveStatus !== 'connected') {
    liveStatus = 'connected';
    publish('status', { message: `LIVE aktif: @${connectedUsername}` });
  }
}

app.get('/api/status', (_req,res) => res.json(snapshot()));
app.post('/api/connect', async (req,res) => {
  const username = String(req.body.username || '').trim().replace(/^@/, '');
  if (!username) return res.status(400).json({ error: 'Masukkan username TikTok.' });
  try {
    if (liveConnection) { try { await liveConnection.disconnect(); } catch {} liveConnection = null; }
    connectedUsername = username;
    liveConnection = new TikTokLiveConnection(username, {
      // Hindari pemrosesan batch awal yang tidak diperlukan dashboard.
      processInitialData: false,
      fetchRoomInfoOnConnect: true
    });
    setStatus('connecting', `Menghubungkan ke @${username}...`);

    liveConnection.on(WebcastEvent.CONNECTED, (state) => {
      setStatus('connected', `Terhubung ke @${username}`);
      if (state?.roomInfo?.user_count) stats.viewers = Number(state.roomInfo.user_count) || 0;
      io.emit('dashboard:update', snapshot());
    });
    liveConnection.on(WebcastEvent.DISCONNECTED, () => setStatus('disconnected', 'Koneksi LIVE terputus.'));
    liveConnection.on(WebcastEvent.ERROR, (err) => publish('error', { message: err?.message || 'Terjadi kesalahan koneksi.' }));
    liveConnection.on(WebcastEvent.CHAT, (data) => {
      markConnectedFromEvent();
      stats.comments++;
      publish('comment', { nickname: data?.user?.nickname || data?.user?.uniqueId || 'Penonton', username: data?.user?.uniqueId || '', message: data?.comment || '' });
    });
    liveConnection.on(WebcastEvent.GIFT, (data) => {
      markConnectedFromEvent();
      const user = data?.user || {};
      const gift = data?.gift || {};
      // TikTok connector exposes the public @handle as user.uniqueId (or displayId
      // on some payload versions). Do not substitute nickname when a handle exists.
      const username = String(user.uniqueId || user.displayId || user.display_id || '').replace(/^@/, '');
      const nickname = user.nickname || user.displayName || user.display_name || username || 'Penonton';
      const senderKey = username || String(user.id || data?.senderUserId || `anonymous-${Date.now()}`);
      const giftName = gift.name || data?.giftName || data?.giftDetails?.giftName || 'Gift';
      const repeat = Math.max(1, Number(data?.repeatCount || data?.comboCount || 1));
      const giftType = Number(gift.type ?? data?.giftType ?? data?.giftDetails?.giftType ?? 0);
      const repeatEnd = data?.repeatEnd === true || data?.repeatEnd === 1 || data?.repeatEnd === '1';
      // Streakable gifts report cumulative progress. Count only the final frame.
      if (giftType === 1 && !repeatEnd) return;
      const diamondCount = Number(gift.diamondCount ?? data?.diamondCount ?? data?.giftDetails?.diamondCount ?? 0);
      const coins = Math.max(0, diamondCount * repeat);
      if (!coins) {
        console.warn('Gift diterima tetapi nilai diamond tidak ditemukan:', JSON.stringify(data));
      }
      stats.gifts += repeat;
      stats.diamonds += coins;
      // Dashboard gifter leaderboard tetap merekam semua gift selama LIVE.
      const old = leaderboard.get(senderKey) || { username, nickname, coins: 0, gifts: 0, lastGift: '', lastGiftCoins: 0 };
      old.coins += coins;
      old.gifts += repeat;
      old.nickname = nickname;
      old.username = username;
      old.lastGift = giftName;
      old.lastGiftCoins = coins;
      leaderboard.set(senderKey, old);

      // Papan peserta lelang hanya menerima gift ketika timer benar-benar berjalan.
      let auctionTotalCoins = null;
      if (auction.status === 'running' && coins > 0) {
        const participant = auctionParticipants.get(senderKey) || { username, nickname, coins: 0, gifts: 0 };
        participant.coins += coins;
        participant.gifts += repeat;
        participant.username = username;
        participant.nickname = nickname;
        auctionParticipants.set(senderKey, participant);
        auctionTotalCoins = participant.coins;
        applyAuctionBid(nickname, username || senderKey, coins);
        updateDrawCountdown();
      }
      publish('gift', {
        nickname, username, giftName, repeat, coins,
        totalCoins: old.coins,
        auctionTotalCoins,
        auctionBidApplied: auction.status === 'running' && coins > 0,
        highestUsername: auction.highestUsername
      });
    });
    liveConnection.on(WebcastEvent.LIKE, (data) => {
      markConnectedFromEvent();
      const count = Number(data?.likeCount || 1); stats.likes += count;
      publish('like', { nickname: data?.user?.nickname || data?.user?.uniqueId || 'Penonton', count });
    });
    liveConnection.on(WebcastEvent.FOLLOW, (data) => {
      markConnectedFromEvent();
      stats.follows++;
      publish('follow', { nickname: data?.user?.nickname || data?.user?.uniqueId || 'Penonton' });
    });
    const result = await liveConnection.connect();
    res.json({ ok: true, message: `Permintaan koneksi ke @${username} dikirim.`, roomId: result?.roomId || null });
  } catch (err) {
    const errorMessage = err?.message || 'Gagal menghubungkan TikTok LIVE.';
    console.error('TikTok connection error:', err);
    setStatus('error', errorMessage);
    res.status(500).json({ error: errorMessage });
  }
});
app.post('/api/disconnect', async (_req,res) => {
  try { if (liveConnection) await liveConnection.disconnect(); } catch {}
  liveConnection = null; connectedUsername = ''; setStatus('disconnected', 'TikTok LIVE diputus.');
  res.json({ ok: true });
});
app.post('/api/test-event', (req,res) => {
  const { type = 'gift', nickname = 'Test Viewer', coins = 10, message = 'Halo Azkaa!' } = req.body || {};
  if (type === 'gift') {
    const value = Math.max(0, Number(coins) || 0); stats.gifts++; stats.diamonds += value;
    const old = leaderboard.get('test-viewer') || { username: 'test-viewer', nickname, coins: 0, gifts: 0 };
    old.coins += value; old.gifts++; leaderboard.set('test-viewer', old);
    let auctionTotalCoins = null;
    if (auction.status === 'running' && value > 0) {
      const participant = auctionParticipants.get('test-viewer') || { username: 'test-viewer', nickname, coins: 0, gifts: 0 };
      participant.coins += value; participant.gifts++; auctionParticipants.set('test-viewer', participant);
      auctionTotalCoins = participant.coins;
      applyAuctionBid(nickname, 'test-viewer', value);
      updateDrawCountdown();
    }
    publish('gift', { nickname, username: 'test-viewer', giftName: 'Test Gift', repeat: 1, coins: value, totalCoins: old.coins, auctionTotalCoins, test: true });
  } else if (type === 'comment') { stats.comments++; publish('comment', { nickname, message, test: true }); }
  else if (type === 'like') { stats.likes += 10; publish('like', { nickname, count: 10, test: true }); }
  else if (type === 'follow') { stats.follows++; publish('follow', { nickname, test: true }); }
  res.json({ ok: true, state: snapshot() });
});
app.post('/api/reset', (_req,res) => {
  Object.keys(stats).forEach(k => stats[k] = 0); leaderboard.clear(); activity.length = 0;
  io.emit('dashboard:update', snapshot()); res.json({ ok: true });
});
app.get('/api/auction', (_req,res) => res.json(auctionSnapshot()));
app.post('/api/auction/start', (req,res) => {
  const title = String(req.body.title || auction.title).trim().slice(0,100) || 'Lelang Item';
  const duration = Math.min(3600, Math.max(5, Number(req.body.durationSeconds) || 60));
  auction.title = title; auction.durationSeconds = duration;
  auction.extraSeconds = Math.min(300, Math.max(0, Number(req.body.extraSeconds) || 0));
  auction.extensionWindowSeconds = Math.min(300, Math.max(1, Number(req.body.extensionWindowSeconds) || 10));
  auctionParticipants.clear(); // Setiap mulai lelang dimulai dengan papan peserta kosong.
  auction.currentBid = Math.max(0, Number(req.body.startingBid) || 0);
  auction.highestBid = ''; auction.highestNickname = ''; auction.bidCount = 0;
  auction.remainingMs = duration * 1000; auction.startedAt = Date.now(); auction.drawActive = false; auction.drawEndsAt = null; auction.drawPreviousEndsAt = null;
  startAuctionTimer();
  io.emit('dashboard:update', snapshot());
  res.json({ ok: true, auction: auctionSnapshot() });
});
app.post('/api/auction/pause', (_req,res) => {
  if (auction.status === 'running') { auction.remainingMs = Math.max(0, auction.endsAt - Date.now()); stopAuctionTimer(); auction.endsAt = null; auction.status = 'paused'; publishAuction('Lelang dijeda.'); }
  res.json({ ok: true, auction: auctionSnapshot() });
});
app.post('/api/auction/resume', (_req,res) => {
  if (auction.status === 'paused' && auction.remainingMs > 0) startAuctionTimer();
  res.json({ ok: true, auction: auctionSnapshot() });
});
app.post('/api/auction/end', (_req,res) => { if (auction.status === 'running' || auction.status === 'paused') finishAuction(); res.json({ ok: true, auction: auctionSnapshot() }); });
app.post('/api/auction/reset', (_req,res) => {
  stopAuctionTimer();
  Object.assign(auction, { status:'idle', remainingMs:0, endsAt:null, currentBid:0, highestBidder:'', highestUsername:'', highestNickname:'', bidCount:0, startedAt:null, drawActive:false, drawEndsAt:null, drawRemainingMs:0, drawPreviousEndsAt:null });
  // Reset lelang juga mengosongkan daftar peserta/gift agar sesi berikutnya mulai bersih.
  leaderboard.clear();
  auctionParticipants.clear();
  stats.gifts = 0; stats.diamonds = 0;
  activity.length = 0;
  io.emit('dashboard:update', snapshot());
  publishAuction('Lelang dan daftar peserta berhasil direset.');
  res.json({ ok:true, auction:auctionSnapshot(), state:snapshot() });
});
app.post('/api/auction/test-bid', (req,res) => {
  const nickname = String(req.body.nickname || 'Test Viewer');
  const coins = Math.max(0, Number(req.body.coins) || 10);
  if (auction.status === 'running' && coins > 0) {
    const participant = auctionParticipants.get('test-viewer') || { username:'test-viewer', nickname, coins:0, gifts:0 };
    participant.coins += coins; participant.gifts++; auctionParticipants.set('test-viewer', participant);
    applyAuctionBid(nickname, 'test-viewer', coins); updateDrawCountdown();
    io.emit('dashboard:update', snapshot());
  }
  res.json({ ok:true, auction:auctionSnapshot() });
});
app.get('/overlay', (_req,res) => res.sendFile(path.join(__dirname, 'public', 'overlay.html')));

io.on('connection', socket => { socket.emit('dashboard:update', snapshot()); socket.emit('auction:update', { auction: auctionSnapshot(), message: '' }); });
server.listen(PORT, () => console.log(`Azkaa LIVE Tools berjalan di http://localhost:${PORT}`));
